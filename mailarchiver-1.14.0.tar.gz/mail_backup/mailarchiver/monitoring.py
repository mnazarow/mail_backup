"""
Мониторинг: метрики для Prometheus/Zabbix и еженедельная сводка администраторам.

``/metrics`` отдаёт состояние в текстовом формате Prometheus (его же понимает
Zabbix: элемент «HTTP-агент» + предобработка «Prometheus pattern»). Доступ —
по токену (``Authorization: Bearer …``) и/или с разрешённых адресов; без
настройки — только с самого сервера.

Сводка (``notifications.summary_cron``, по умолчанию по понедельникам в 8:00)
приходит письмом: что с ящиками (неверные пароли, давно не копировались,
ошибки), сколько скопировано за неделю, место на диске и прогноз, прежние
копии после копирования «с нуля», копия вне сервера, события безопасности.
Ящики «требуют внимания» по тем же правилам, что и на дашборде.
"""
from __future__ import annotations

import shutil
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple

from .logging_setup import get_logger
from .models import account_has_credentials
from .util import human_size
from .version import __version__

log = get_logger("monitoring")

#: Через сколько часов без удачной копии включённый ящик считается «давно не копировался»
#: (как фильтр «Копия старше 72 ч» в разделе «Почтовые ящики»).
STALE_HOURS = 72
#: Как часто пересчитывать тяжёлую часть (итоги по ящикам): Prometheus опрашивает
#: раз в 15–60 секунд, а полный подсчёт писем на большом архиве занимает секунды.
HEAVY_TTL_S = 300
#: Лёгкие метрики (очередь, диск) — не чаще раза в 10 секунд.
LIGHT_TTL_S = 10

_cache_lock = threading.Lock()
_cache: Dict[str, Tuple[float, object]] = {}


def _cached(name: str, ttl: float, fn):
    now = time.time()
    with _cache_lock:
        hit = _cache.get(name)
        if hit and now - hit[0] < ttl:
            return hit[1]
    value = fn()
    with _cache_lock:
        _cache[name] = (now, value)
    return value


def reset_cache() -> None:
    with _cache_lock:
        _cache.clear()


def _parse_iso(value) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
#  Сбор состояния
# ---------------------------------------------------------------------------
def account_problems(svc) -> Dict:
    """Ящики по состояниям — по тем же правилам, что дашборд и отборы ящиков."""
    def compute():
        now = datetime.now(timezone.utc)
        totals = svc.db.message_totals_by_account()
        last_runs = svc.db.last_runs_by_account()
        rows = []
        out = {"total": 0, "enabled": 0, "badpw": [], "nobackup": [], "stale": [], "failed": [],
               "nopassword": [], "accounts": rows, "messages": 0, "bytes": 0}
        for acc in svc.db.list_accounts():
            t = totals.get(acc.id) or {}
            msgs, size = int(t.get("messages", 0)), int(t.get("bytes", 0))
            out["messages"] += msgs
            out["bytes"] += size
            out["total"] += 1
            last_ok = _parse_iso(acc.last_backup_at)
            has_secret = account_has_credentials(acc)
            run = last_runs.get(acc.id)
            item = {"id": acc.id, "name": acc.name, "username": acc.username, "enabled": bool(acc.enabled),
                    "messages": msgs, "bytes": size, "last_backup_at": acc.last_backup_at or "",
                    "login_ok": acc.login_status == "ok", "login_status": acc.login_status or ""}
            rows.append(item)
            if not acc.enabled:
                continue
            out["enabled"] += 1
            if acc.secret_broken or acc.login_status in ("auth_error", "secret_broken"):
                out["badpw"].append(item)
            elif not has_secret:
                out["nopassword"].append(item)
            if not acc.last_backup_at and not msgs:
                out["nobackup"].append(item)
            elif last_ok is None or now - last_ok > timedelta(hours=STALE_HOURS):
                out["stale"].append(item)
            status = run["status"] if run is not None else (acc.last_backup_status or "")
            if status == "failed":
                out["failed"].append(item)
        return out
    return _cached("accounts", HEAVY_TTL_S, compute)


def quarantines(svc) -> Dict:
    """Прежние копии ящиков (карантин после «с нуля»): число, размер, письма «только здесь»."""
    from .quarantine import overview
    try:
        return _cached("quarantines", HEAVY_TTL_S, lambda: overview(svc))
    except Exception as exc:  # noqa: BLE001 — метрики и сводка не должны падать из-за карантина
        log.warning("Не удалось собрать сведения о прежних копиях: %s", exc)
        return {"count": 0, "accounts": 0, "checked": 0, "unchecked": 0, "bytes": 0, "with_unique": 0,
                "unique": 0, "unique_bytes": 0, "oldest_created_at": None, "items": []}


def collect(svc) -> Dict:
    """Всё состояние для метрик и сводки."""
    acc = account_problems(svc)

    def light():
        counts = svc.db.count_jobs_by_status()
        since_24h = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        failed_24h = int(svc.db.scalar("SELECT COUNT(*) FROM jobs WHERE status='failed' AND finished_at>=?",
                                       (since_24h,)) or 0)
        try:
            usage = shutil.disk_usage(svc.cfg.mail_root)
            disk = {"free": usage.free, "total": usage.total}
        except OSError:
            disk = {"free": 0, "total": 0}
        since_1h = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        failures = {r["kind"] or "password": int(r["c"]) for r in svc.db.query(
            "SELECT kind, COUNT(*) AS c FROM login_attempts WHERE success=0 AND ts>=? GROUP BY kind", (since_1h,))}
        return {"jobs": {"queued": int(counts.get("queued", 0)), "running": int(counts.get("running", 0)),
                         "failed_24h": failed_24h},
                "disk": disk, "login_failures_1h": failures}
    state = _cached("light", LIGHT_TTL_S, light)
    from .replica import runner as replica_runner
    from .replica import snapshots
    rep = replica_runner.status(svc)
    snaps = snapshots.list_snapshots(svc.cfg)
    return {"accounts": acc, **state, "quarantines": quarantines(svc),
            "encryption": {"active": bool(svc.store.encrypt), "blocked": bool(svc.store.encryption_blocked)},
            "scheduler_running": bool(svc.scheduler.running()),
            "replica": rep, "snapshot": snaps[0] if snaps else None}


# ---------------------------------------------------------------------------
#  Prometheus
# ---------------------------------------------------------------------------
def _label(value) -> str:
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _ts(value) -> Optional[float]:
    dt = _parse_iso(value)
    return dt.timestamp() if dt else None


class _Out:
    def __init__(self) -> None:
        self.lines: List[str] = []

    def metric(self, name: str, help_text: str, kind: str, samples) -> None:
        self.lines.append(f"# HELP {name} {help_text}")
        self.lines.append(f"# TYPE {name} {kind}")
        for labels, value in samples:
            if value is None:
                continue
            lab = ",".join(f'{k}="{_label(v)}"' for k, v in labels.items()) if labels else ""
            num = int(value) if isinstance(value, bool) else value
            text = repr(float(num)) if isinstance(num, float) else str(int(num))
            self.lines.append(f"{name}{{{lab}}} {text}" if lab else f"{name} {text}")

    def text(self) -> str:
        return "\n".join(self.lines) + "\n"


def render_prometheus(svc, *, per_account: bool = True) -> str:
    data = collect(svc)
    acc = data["accounts"]
    out = _Out()
    out.metric("mailarchiver_info", "Версия службы", "gauge", [({"version": __version__}, 1)])
    out.metric("mailarchiver_accounts", "Ящики по состояниям (как на дашборде)", "gauge", [
        ({"state": "total"}, acc["total"]), ({"state": "enabled"}, acc["enabled"]),
        ({"state": "bad_password"}, len(acc["badpw"])), ({"state": "no_backup"}, len(acc["nobackup"])),
        ({"state": "stale"}, len(acc["stale"])), ({"state": "last_failed"}, len(acc["failed"])),
        ({"state": "no_password"}, len(acc["nopassword"]))])
    out.metric("mailarchiver_messages", "Писем в архиве", "gauge", [({}, acc["messages"])])
    out.metric("mailarchiver_messages_bytes", "Объём писем в архиве, байт", "gauge", [({}, acc["bytes"])])
    jobs = data["jobs"]
    out.metric("mailarchiver_jobs", "Задания в очереди и выполняющиеся", "gauge",
               [({"status": "queued"}, jobs["queued"]), ({"status": "running"}, jobs["running"])])
    out.metric("mailarchiver_jobs_failed_24h", "Заданий с ошибкой за сутки", "gauge", [({}, jobs["failed_24h"])])
    out.metric("mailarchiver_disk_free_bytes", "Свободно на диске с письмами, байт", "gauge",
               [({}, data["disk"]["free"])])
    out.metric("mailarchiver_disk_total_bytes", "Размер диска с письмами, байт", "gauge",
               [({}, data["disk"]["total"])])
    out.metric("mailarchiver_encryption_blocked", "Шифрование включено, а ключа нет (копирование стоит)", "gauge",
               [({}, data["encryption"]["blocked"])])
    out.metric("mailarchiver_scheduler_running", "Работает ли планировщик расписаний", "gauge",
               [({}, data["scheduler_running"])])
    rep = data["replica"]
    last = rep.get("last_run") or {}
    out.metric("mailarchiver_replica_enabled", "Включена ли копия вне сервера", "gauge", [({}, rep["enabled"])])
    out.metric("mailarchiver_replica_last_success_timestamp_seconds", "Время последней удачной копии вне сервера",
               "gauge", [({}, _ts(rep.get("last_ok")))])
    out.metric("mailarchiver_replica_last_run_ok", "Последний прогон копии вне сервера без ошибок (1/0)", "gauge",
               [({}, last.get("status") == "success")] if last else [])
    snap = data.get("snapshot")
    out.metric("mailarchiver_db_snapshot_timestamp_seconds", "Время самого свежего снимка базы", "gauge",
               [({}, _ts(snap["created_at"]))] if snap else [])
    out.metric("mailarchiver_login_failures_1h", "Неудачных входов за час по видам", "gauge",
               [({"kind": kind}, n) for kind, n in sorted(data["login_failures_1h"].items())]
               or [({"kind": "password"}, 0)])
    oldest = None
    now = datetime.now(timezone.utc)
    for item in acc["accounts"]:
        if not item["enabled"]:
            continue
        dt = _parse_iso(item["last_backup_at"])
        age = (now - dt).total_seconds() if dt else None
        if age is not None and (oldest is None or age > oldest):
            oldest = age
    out.metric("mailarchiver_oldest_backup_age_seconds",
               "Сколько секунд назад была последняя удачная копия у самого «отстающего» включённого ящика",
               "gauge", [({}, oldest)])
    q = data["quarantines"]
    out.metric("mailarchiver_quarantines", "Прежние копии ящиков после копирования «с нуля»", "gauge", [
        ({"state": "total"}, q["count"]), ({"state": "unchecked"}, q["unchecked"]),
        ({"state": "with_unique"}, q["with_unique"])])
    out.metric("mailarchiver_quarantine_bytes", "Объём сравненных прежних копий на диске, байт", "gauge",
               [({}, q["bytes"])])
    out.metric("mailarchiver_quarantine_unique_messages",
               "Писем, которые есть только в прежних копиях (нет в архиве)", "gauge", [({}, q["unique"])])
    out.metric("mailarchiver_quarantine_oldest_age_seconds", "Возраст самой старой прежней копии, секунд", "gauge",
               [({}, max(0.0, time.time() - q["oldest_created_at"]))] if q["oldest_created_at"] else [])
    try:
        from .axigen.monitor import metrics as axigen_metrics
        for name, help_text, kind, samples in axigen_metrics(svc):
            out.metric(name, help_text, kind, samples)
    except Exception:  # noqa: BLE001 — метрики Axigen не должны ломать остальные
        pass
    try:
        from .mailservers.monitor import metrics as mailserver_metrics
        for name, help_text, kind, samples in mailserver_metrics(svc):
            out.metric(name, help_text, kind, samples)
    except Exception:  # noqa: BLE001 — и метрики подключённых серверов тоже
        pass
    if per_account:
        rows = acc["accounts"]

        def labels(item):
            return {"account_id": item["id"], "account": item["name"], "username": item["username"]}
        out.metric("mailarchiver_account_enabled", "Ящик включён в копирование", "gauge",
                   [(labels(i), i["enabled"]) for i in rows])
        out.metric("mailarchiver_account_last_backup_timestamp_seconds", "Последняя удачная копия ящика", "gauge",
                   [(labels(i), _ts(i["last_backup_at"])) for i in rows])
        out.metric("mailarchiver_account_login_ok", "Последний вход в ящик удался (1/0)", "gauge",
                   [(labels(i), i["login_ok"]) for i in rows if i["login_status"]])
        out.metric("mailarchiver_account_messages", "Писем ящика в архиве", "gauge",
                   [(labels(i), i["messages"]) for i in rows])
        out.metric("mailarchiver_account_bytes", "Объём писем ящика в архиве, байт", "gauge",
                   [(labels(i), i["bytes"]) for i in rows])
        per_q: Dict[int, int] = {}
        for item in q["items"]:
            per_q[item["account_id"]] = per_q.get(item["account_id"], 0) + 1
        out.metric("mailarchiver_account_quarantines", "Прежних копий у ящика", "gauge",
                   [(labels(i), per_q[i["id"]]) for i in rows if i["id"] in per_q])
    return out.text()


# ---------------------------------------------------------------------------
#  Еженедельная сводка
# ---------------------------------------------------------------------------
def _num(value) -> str:
    """Число с разрядами через пробел: 12 345."""
    return f"{int(value or 0):,}".replace(",", " ")


def _names(items: List[Dict], limit: int = 20) -> str:
    shown = [f"{i['name']} ({i['username']})" if i.get("username") and i["username"] != i["name"] else i["name"]
             for i in items[:limit]]
    more = len(items) - limit
    return "; ".join(shown) + (f" и ещё {more}" if more > 0 else "")


def weekly_summary(svc, days: int = 7, *, fresh: bool = True, security: bool = True) -> Tuple[str, str]:
    """Тема и текст письма-сводки за последние ``days`` дней.

    ``fresh=False`` — взять состояние ящиков из кэша (до 5 минут): предпросмотр в
    интерфейсе не должен пересчитывать весь архив на каждое нажатие.
    ``security=False`` — без строки о неудачных входах (предпросмотр оператора).
    """
    if fresh:
        reset_cache()
    data = collect(svc)
    acc = data["accounts"]
    tz = svc.local_tz()
    now = datetime.now(timezone.utc)
    since = now - timedelta(days=days)
    since_iso = since.isoformat()
    runs = svc.db.query_one(
        "SELECT COUNT(*) AS n, COALESCE(SUM(CASE WHEN status IN ('success','partial') THEN 1 ELSE 0 END),0) AS ok, "
        "COALESCE(SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END),0) AS bad, "
        "COALESCE(SUM(messages_new),0) AS msgs, COALESCE(SUM(bytes_new),0) AS bytes "
        "FROM runs WHERE type='backup' AND started_at>=?", (since_iso,))
    failed_jobs = int(svc.db.scalar("SELECT COUNT(*) FROM jobs WHERE status='failed' AND finished_at>=?",
                                    (since_iso,)) or 0)
    sec = svc.db.query_one(
        "SELECT COALESCE(SUM(CASE WHEN COALESCE(kind,'')='' THEN 1 ELSE 0 END),0) AS pw, "
        "COALESCE(SUM(CASE WHEN kind='otp' THEN 1 ELSE 0 END),0) AS otp, "
        "COALESCE(SUM(CASE WHEN kind='imap' THEN 1 ELSE 0 END),0) AS imap "
        "FROM login_attempts WHERE success=0 AND ts>=?", (since_iso,))
    problems = len(acc["badpw"]) + len(acc["nobackup"]) + len(acc["stale"]) + len(acc["failed"])
    rep = data["replica"]
    rep_problem = False
    period = f"{since.astimezone(tz):%d.%m}–{now.astimezone(tz):%d.%m.%Y}"
    lines = [f"MailArchiver {__version__}: сводка за {period}", ""]
    lines.append(f"Ящиков: {acc['total']} (копируются: {acc['enabled']}).")
    if runs is not None:
        # разряды отделяем пробелом только в самих числах: прежний .replace(",", " ")
        # по всей строке съедал и запятые между словами («прогонов 1  удачных 0»)
        lines.append(f"Копирование за неделю: прогонов {_num(runs['n'])}, удачных {_num(runs['ok'])}, "
                     f"с ошибкой {_num(runs['bad'])}; новых писем {_num(runs['msgs'])} "
                     f"({human_size(int(runs['bytes']))}).")
    lines.append(f"Архив: писем {_num(acc['messages'])}, объём {human_size(acc['bytes'])}.")
    disk = data["disk"]
    if disk["total"]:
        text = f"Диск с письмами: свободно {human_size(disk['free'])} из {human_size(disk['total'])}"
        grow = _daily_growth(svc, 28)
        if grow > 0:
            days_left = int(disk["free"] / grow)
            text += f"; при нынешнем приросте (~{human_size(grow)} в день) места хватит примерно на {days_left} дн."
            if days_left < 60:
                problems += 1
                text += " ⚠ пора расширять диск или сокращать сроки хранения"
        lines.append(text + ".")
    lines.append("")
    if problems:
        lines.append("ТРЕБУЮТ ВНИМАНИЯ")
        for key, title in (("badpw", "Неверный пароль (копирование не идёт)"),
                           ("failed", "Последнее копирование с ошибкой"),
                           ("stale", f"Нет удачной копии дольше {STALE_HOURS} ч"),
                           ("nobackup", "Ни одной резервной копии")):
            if acc[key]:
                lines.append(f"• {title} — {len(acc[key])}: {_names(acc[key])}")
        lines.append("")
    else:
        lines.append("Все включённые ящики копируются без замечаний.")
        lines.append("")
    if acc["nopassword"]:
        lines.append(f"Включены, но без пароля — {len(acc['nopassword'])}: {_names(acc['nopassword'], 10)}")
    q_lines, q_problem = _quarantine_lines(data["quarantines"], tz, now)
    lines.extend(q_lines)
    problems += q_problem
    if failed_jobs:
        lines.append(f"Заданий с ошибкой за неделю: {failed_jobs} (подробно — «Очередь и задания»).")
    if rep["enabled"]:
        last = rep.get("last_run") or {}
        last_ok = _parse_iso(rep.get("last_ok"))
        if last_ok is None or now - last_ok > timedelta(hours=48):
            rep_problem = True
            lines.append("⚠ Копия вне сервера: удачного прогона не было больше 48 ч"
                         + (f" (последний: {last.get('status')} — {last.get('message', '')[:300]})" if last else "") + ".")
        else:
            lines.append(f"Копия вне сервера: последняя удачная {last_ok.astimezone(tz):%d.%m %H:%M}"
                         + (" — С ЗАМЕЧАНИЯМИ: " + last.get("message", "")[:300] if last.get("status") == "partial" else "")
                         + ".")
    else:
        lines.append("Копия вне сервера не настроена: архив хранится в одном экземпляре "
                     "(«Настройки → Копия вне сервера и снимки базы»).")
    snap = data.get("snapshot")
    if snap:
        created = _parse_iso(snap["created_at"])
        lines.append(f"Снимок базы: {created.astimezone(tz):%d.%m %H:%M}, {human_size(snap['size'])}.")
    else:
        lines.append("Снимков базы нет.")
    if data["encryption"]["blocked"]:
        problems += 1
        lines.append("⛔ Шифрование включено, а ключа нет — новые письма не сохраняются!")
    try:
        from .axigen.monitor import problems as axigen_problems, summary_lines as axigen_summary
        ax_lines = axigen_summary(svc)
        if ax_lines:
            lines.extend(ax_lines)
            problems += len(axigen_problems(svc))
    except Exception:  # noqa: BLE001 — сводка уходит и без раздела Axigen
        pass
    try:
        from .mailservers.monitor import problems as ms_problems, summary_lines as ms_summary
        ms_lines = ms_summary(svc)
        if ms_lines:
            lines.extend(ms_lines)
            problems += len(ms_problems(svc))
    except Exception:  # noqa: BLE001
        pass
    if security and sec is not None and (sec["pw"] or sec["otp"] or sec["imap"]):
        lines.append(f"Безопасность за неделю: неудачных входов {sec['pw']}, неверных кодов 2FA {sec['otp']}, "
                     f"неудачных проверок паролей ящиков {sec['imap']}.")
    lines.append("")
    base = str(svc.rt("server", "public_url") or "").rstrip("/")
    if base:
        lines.append(f"Открыть MailArchiver: {base}/")
    lines.append("Письмо отправлено службой MailArchiver (настройка «Еженедельная сводка» в разделе «Уведомления»).")
    total_problems = problems + (1 if rep_problem else 0)
    subject = (f"MailArchiver: сводка за неделю — требуют внимания: {total_problems}" if total_problems
               else "MailArchiver: сводка за неделю — всё в порядке")
    return subject, "\n".join(lines) + "\n"


#: Прежняя копия старше стольких дней упоминается в сводке отдельно: она
#: занимает место, а письма «только в ней» не видны ни в поиске, ни в выгрузке.
QUARANTINE_OLD_DAYS = 30


def _quarantine_lines(q: Dict, tz, now: datetime) -> Tuple[List[str], int]:
    """Строки сводки о прежних копиях и число «требующих внимания» (0 или 1)."""
    if not q.get("count"):
        return [], 0
    lines = []
    n_acc = q["accounts"]
    text = (f"Прежние копии после копирования «с нуля»: {q['count']} у {n_acc} "
            f"{'ящика' if n_acc % 10 == 1 and n_acc % 100 != 11 else 'ящиков'}")
    if q["checked"]:
        text += f", сравнено {q['checked']} (на диске {human_size(q['bytes'])})"
    if q["unchecked"]:
        text += f", ещё не сравнивались: {q['unchecked']}"
    lines.append(text + ".")
    problem = 0
    if q["unique"]:
        problem = 1
        owners = sorted({i["account"] for i in q["items"] if i["unique"]})
        shown = "; ".join(owners[:10]) + (f" и ещё {len(owners) - 10}" if len(owners) > 10 else "")
        lines.append(f"⚠ Писем только в прежних копиях (в архиве их нет): {_num(q['unique'])} "
                     f"({human_size(q['unique_bytes'])}) — {shown}. Верните их кнопкой «🛟 Вернуть» "
                     f"(меню ящика → «Прежние копии»), прежде чем удалять копии.")
    oldest = q.get("oldest_created_at")
    if oldest:
        age_days = int((now.timestamp() - oldest) // 86400)
        if age_days >= QUARANTINE_OLD_DAYS:
            lines.append(f"Самой старой прежней копии {age_days} дн. (от "
                         f"{datetime.fromtimestamp(oldest, tz):%d.%m.%Y}): если письма из неё не нужны, "
                         f"её можно удалить и освободить место.")
    return lines, problem


def _daily_growth(svc, days: int) -> float:
    """Средний прирост архива в байтах в день за последние ``days`` дней."""
    since = (datetime.now(svc.local_tz()).date() - timedelta(days=days)).isoformat()
    total = int(svc.db.scalar("SELECT COALESCE(SUM(bytes),0) FROM stats_daily WHERE day>=?", (since,)) or 0)
    return total / float(days) if total else 0.0


def send_weekly_summary(svc) -> Dict:
    """Отправить сводку сейчас. Не бросает исключений — возвращает итог."""
    subject, body = weekly_summary(svc)
    try:
        svc.notifier.send(subject, body)
    except Exception as exc:  # noqa: BLE001
        log.warning("Сводка не отправлена: %s", exc)
        return {"ok": False, "error": str(exc), "subject": subject}
    svc.db.set_meta("summary_last_sent", datetime.now(timezone.utc).isoformat())
    return {"ok": True, "subject": subject}


# ---------------------------------------------------------------------------
#  Доступ к /metrics
# ---------------------------------------------------------------------------
def metrics_access(svc, client_ip: str, auth_header: str) -> Tuple[bool, int]:
    """(разрешено, http-код при отказе). Токен сравнивается за постоянное время."""
    import hmac
    import ipaddress
    if not bool(svc.rt("monitoring", "metrics_enabled")):
        return False, 404
    token = str(svc.rt("monitoring", "metrics_token") or "")
    if token:
        given = ""
        if auth_header.lower().startswith("bearer "):
            given = auth_header[7:].strip()
        if given and hmac.compare_digest(given.encode(), token.encode()):
            return True, 200
    allowed = svc.rt("monitoring", "metrics_allowed_ips") or []
    if isinstance(allowed, str):
        allowed = [p for p in allowed.replace(";", ",").split(",")]
    try:
        ip = ipaddress.ip_address((client_ip or "").strip())
    except ValueError:
        return False, 401 if token else 403
    for item in allowed:
        item = str(item).strip()
        if not item:
            continue
        try:
            if ip in ipaddress.ip_network(item, strict=False):
                return True, 200
        except ValueError:
            continue
    return False, 401 if token else 403
