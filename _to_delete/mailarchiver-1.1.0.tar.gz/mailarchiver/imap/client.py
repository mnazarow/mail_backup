"""
Обёртка над IMAPClient с надёжной обработкой ошибок, таймаутами, повторными
подключениями, поддержкой SSL/STARTTLS/без шифрования, входом по паролю и по
OAuth2 (XOAUTH2).
"""
from __future__ import annotations

import imaplib
import socket
import ssl
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterator, List, Optional, Set

from imapclient import IMAPClient
from imapclient.exceptions import LoginError

from ..errors import (
    ImapAuthError,
    ImapConnectionError,
    ImapProtocolError,
    ImapTimeoutError,
)
from ..logging_setup import get_logger
from ..models import Account, AuthType, Security
from .oauth import refresh_access_token

log = get_logger("imap")

# Целевой СУММАРНЫЙ объём одной порции FETCH (байты). Порция набирается по
# размеру писем, а не по их количеству: батч из 200 писем с вложениями по
# 20-30 МБ забирал бы в память несколько гигабайт за один запрос (OOM).
FETCH_CHUNK_TARGET_BYTES = 64 * 1024 * 1024
# Сколько UID спрашивать за один запрос размеров: ответ на (RFC822.SIZE)
# крошечный, поэтому порция здесь заметно крупнее порции загрузки.
SIZE_PROBE_BATCH_SIZE = 2000
# Во что оценивать письмо, размер которого сервер не сообщил. Нужно только
# для набора порции: без оценки такие письма считались бы «нулевыми» и порция
# опять набиралась бы одним лишь количеством.
UNKNOWN_SIZE_ASSUMPTION = 256 * 1024

# Признаки ответа «папка уже существует». Подстрока «exist» для этого не
# годится: ответ вида `NO [TRYCREATE] Mailbox doesn't exist` — это ОТКАЗ.
_ALREADY_EXISTS_MARKERS = ("alreadyexists", "already exist", "duplicate folder", "duplicate mailbox")


@dataclass
class ConnectOptions:
    connect_timeout_s: int = 30
    socket_timeout_s: int = 120
    verify_ssl: bool = True
    fetch_batch_size: int = 200


@dataclass
class FolderInfo:
    name: str
    delimiter: str = "/"
    flags: List[str] = field(default_factory=list)
    selectable: bool = True


def _map_exception(exc: BaseException) -> Exception:
    """Привести низкоуровневую ошибку к нашему типу с понятным сообщением."""
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return ImapTimeoutError("Превышено время ожидания IMAP-сервера.",
                                hint="Увеличьте backup.socket_timeout_s или проверьте сеть/файрвол.", cause=exc)
    if isinstance(exc, ssl.SSLError):
        return ImapConnectionError(f"Ошибка TLS/SSL: {exc}",
                                   hint="Проверьте порт и режим шифрования (SSL vs STARTTLS) и валидность сертификата.",
                                   cause=exc)
    if isinstance(exc, (ConnectionError, socket.gaierror, OSError)):
        return ImapConnectionError(f"Не удалось соединиться с IMAP-сервером: {exc}",
                                   hint="Проверьте адрес хоста, порт и доступность сервера.", cause=exc)
    if isinstance(exc, LoginError):
        return ImapAuthError("Аутентификация IMAP не удалась (неверные логин/пароль или требуется пароль приложения).",
                             hint="Для Gmail/Mail.ru/Яндекс включите доступ по IMAP и используйте пароль приложения, либо OAuth2.",
                             cause=exc)
    if isinstance(exc, imaplib.IMAP4.error):
        text = str(exc).lower()
        if "auth" in text or "login" in text or "credential" in text:
            return ImapAuthError(f"IMAP-сервер отклонил аутентификацию: {exc}", cause=exc)
        return ImapProtocolError(f"Ошибка протокола IMAP: {exc}", cause=exc)
    return ImapProtocolError(f"Неожиданная ошибка IMAP: {exc}", cause=exc)


def _is_already_exists_error(exc: BaseException) -> bool:
    """
    Отличить ответ «папка уже существует» от любого другого отказа CREATE.

    Опираемся на код ответа ALREADYEXISTS (RFC 5530) и явные формулировки
    серверов. Ответы вроде `NO [TRYCREATE] Mailbox doesn't exist` под это
    условие НЕ подпадают — глушить их нельзя, иначе все последующие APPEND в
    эту папку падают без внятной причины.
    """
    text = str(exc).lower()
    return any(marker in text for marker in _ALREADY_EXISTS_MARKERS)


def _header_message_id(raw_header) -> str:
    """Достать значение Message-ID из куска заголовков, отданного сервером."""
    if not raw_header:
        return ""
    if isinstance(raw_header, bytes):
        text = raw_header.decode("latin-1", "ignore")
    else:
        text = str(raw_header)
    for line in text.splitlines():
        if line.lower().startswith("message-id:"):
            return line.split(":", 1)[1].strip()
    return ""


def _plan_size_chunks(uids: List[int], sizes: Dict[int, int], max_count: int,
                      target_bytes: int) -> Iterator[List[int]]:
    """
    Разбить UID на порции по СУММАРНОМУ размеру писем.

    Порция закрывается, когда добавление следующего письма перевалило бы за
    ``target_bytes``, либо когда в ней уже ``max_count`` писем. Письмо, которое
    само больше целевого объёма, из-за этого попадает в порцию в одиночку.
    """
    chunk: List[int] = []
    chunk_bytes = 0
    for uid in uids:
        size = int(sizes.get(uid) or UNKNOWN_SIZE_ASSUMPTION)
        if chunk and (len(chunk) >= max_count or chunk_bytes + size > target_bytes):
            yield chunk
            chunk, chunk_bytes = [], 0
        chunk.append(uid)
        chunk_bytes += size
    if chunk:
        yield chunk


class ImapConnection:
    """Одно соединение с IMAP-ящиком. Используйте как контекстный менеджер."""

    def __init__(self, account: Account, options: Optional[ConnectOptions] = None) -> None:
        self.account = account
        self.opt = options or ConnectOptions()
        self.client: Optional[IMAPClient] = None
        self._delimiter: str = "/"

    # -- контекстный менеджер -----------------------------------------------
    def __enter__(self) -> "ImapConnection":
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        # Если выходим из-за ошибки, соединение может быть уже мёртвым —
        # не тратим время на logout по такому сокету.
        self.close(force=exc_type is not None)

    # -- подключение ---------------------------------------------------------
    def _ssl_context(self) -> ssl.SSLContext:
        ctx = ssl.create_default_context()
        if not self.opt.verify_ssl:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        return ctx

    def _timeout(self):
        """
        Таймауты для самого IMAPClient. Глобальный socket.setdefaulttimeout()
        использовать нельзя: он меняет таймаут для всего процесса (SMTP, OAuth,
        HTTP), а подключаемся мы из рабочих потоков.
        """
        try:
            from imapclient import SocketTimeout  # есть не во всех версиях
            return SocketTimeout(self.opt.connect_timeout_s, self.opt.socket_timeout_s)
        except ImportError:  # старая/другая версия imapclient — один общий таймаут
            return self.opt.socket_timeout_s

    def connect(self) -> None:
        acc = self.account
        timeout = self._timeout()
        try:
            if acc.security == Security.SSL:
                client = IMAPClient(acc.host, port=acc.port or 993, ssl=True,
                                    ssl_context=self._ssl_context(), timeout=timeout)
            else:
                client = IMAPClient(acc.host, port=acc.port or 143, ssl=False, timeout=timeout)
            # Запоминаем клиента СРАЗУ после конструктора: если STARTTLS (или
            # логин) упадёт, close() всё равно закроет уже открытый сокет.
            self.client = client
            if acc.security == Security.STARTTLS:
                client.starttls(self._ssl_context())
            self._login()
            log.info("Подключение к ящику «%s» (%s:%s) установлено", acc.name, acc.host, acc.port)
        except (LoginError, ImapAuthError):
            self.close()
            raise
        except Exception as exc:  # noqa: BLE001
            # ошибка уровня сети/TLS — сокет наверняка непригоден, рвём сразу
            self.close(force=True)
            raise _map_exception(exc) from exc

    def _login(self) -> None:
        acc = self.account
        assert self.client is not None
        try:
            if acc.auth_type == AuthType.OAUTH2:
                access, _exp = refresh_access_token(
                    acc.oauth_token_url, acc.oauth_client_id, acc.oauth_client_secret,
                    acc.oauth_refresh_token, timeout=self.opt.connect_timeout_s,
                )
                self.client.oauth2_login(acc.username, access)
            else:
                self.client.login(acc.username, acc.password)
        except LoginError as exc:
            raise ImapAuthError(
                "Не удалось войти в почтовый ящик: сервер отклонил учётные данные.",
                hint="Проверьте логин/пароль. Возможно, нужен «пароль приложения» или включение IMAP в настройках почты.",
                cause=exc,
            ) from exc

    _CLOSE_TIMEOUT_S = 5

    def close(self, *, force: bool = False) -> None:
        """
        Закрыть соединение.

        При force=True (или при любой ошибке logout) сокет рвётся сразу через
        shutdown(), без ожидания ответа сервера. Иначе на разорванном соединении
        logout() висел бы до socket_timeout_s (до 120 с) при каждом обрыве —
        поэтому перед logout мы ещё и укорачиваем таймаут сокета.
        """
        client = self.client
        self.client = None
        if client is None:
            return
        if not force:
            self._shorten_socket_timeout(client)
            try:
                client.logout()
                return
            except Exception:  # noqa: BLE001
                pass  # сервер не ответил или сокет мёртв — закрываем принудительно
        try:
            client.shutdown()
        except Exception:  # noqa: BLE001
            pass

    @classmethod
    def _shorten_socket_timeout(cls, client) -> None:
        """Ограничить ожидание ответа на LOGOUT (best-effort, зависит от версии)."""
        try:
            sock = client._imap.sock  # noqa: SLF001
            if sock is not None:
                sock.settimeout(cls._CLOSE_TIMEOUT_S)
        except Exception:  # noqa: BLE001
            pass

    # -- операции ------------------------------------------------------------
    def capabilities(self) -> List[str]:
        try:
            return [c.decode() if isinstance(c, bytes) else str(c) for c in self.client.capabilities()]
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc

    def list_folders(self) -> List[FolderInfo]:
        try:
            raw = self.client.list_folders()
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc
        result: List[FolderInfo] = []
        for flags, delimiter, name in raw:
            deli = delimiter.decode() if isinstance(delimiter, bytes) else (delimiter or "/")
            self._delimiter = deli or self._delimiter
            flag_list = [f.decode() if isinstance(f, bytes) else str(f) for f in (flags or ())]
            selectable = "\\Noselect" not in flag_list and "\\NonExistent" not in flag_list
            result.append(FolderInfo(name=name, delimiter=deli or "/", flags=flag_list, selectable=selectable))
        return result

    @property
    def delimiter(self) -> str:
        return self._delimiter

    def select(self, folder: str, readonly: bool = True) -> Dict[str, int]:
        try:
            info = self.client.select_folder(folder, readonly=readonly)
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc
        return {
            "uidvalidity": int(info.get(b"UIDVALIDITY", 0) or 0),
            "uidnext": int(info.get(b"UIDNEXT", 0) or 0),
            "exists": int(info.get(b"EXISTS", 0) or 0),
        }

    def search_all_uids(self) -> List[int]:
        try:
            return list(self.client.search(["ALL"]))
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc

    def search_since(self, date) -> List[int]:
        try:
            return list(self.client.search(["SINCE", date]))
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc

    def fetch_sizes(self, uids: List[int]) -> Dict[int, int]:
        """
        Спросить у сервера ТОЛЬКО размеры писем: `UID FETCH <uids> (RFC822.SIZE)`.

        Запрос дешёвый (тела не передаются), поэтому его можно сделать до
        загрузки и заранее отсеять слишком крупные письма. Возвращает
        {uid: размер}; UID, по которым сервер размер не сообщил, в результат
        не попадают.
        """
        sizes: Dict[int, int] = {}
        if not uids:
            return sizes
        batch = max(1, int(SIZE_PROBE_BATCH_SIZE))
        for start in range(0, len(uids), batch):
            chunk = uids[start:start + batch]
            try:
                data = self.client.fetch(chunk, [b"RFC822.SIZE"])
            except Exception as exc:  # noqa: BLE001
                raise _map_exception(exc) from exc
            for uid, item in (data or {}).items():
                raw_size = (item or {}).get(b"RFC822.SIZE")
                if raw_size is None:
                    continue
                try:
                    sizes[int(uid)] = int(raw_size)
                except (TypeError, ValueError):
                    continue
        return sizes

    def fetch_messages(self, uids: List[int], *, skip_larger_than: int = 0,
                       on_skipped: Optional[Callable[[int, int], None]] = None) -> Iterator[dict]:
        """
        Скачать письма по списку UID. Не помечает их как прочитанные.

        Порядок работы (окнами по ``SIZE_PROBE_BATCH_SIZE`` писем, чтобы не
        держать в памяти размеры всей папки и не молчать до первого письма):
          1. дёшево спросить у сервера только размеры (RFC822.SIZE);
          2. письма больше ``skip_larger_than`` отсеять СРАЗУ, не скачивая —
             о каждом сообщается вызовом ``on_skipped(uid, size)``;
          3. остальные качать порциями, которые набираются по СУММАРНОМУ
             размеру (≈``FETCH_CHUNK_TARGET_BYTES``) и не длиннее
             ``fetch_batch_size`` писем.

        Контракт наружу прежний: генератор словарей
        {uid, raw, flags, internaldate, size}.
        """
        if not uids:
            return
        limit = max(0, int(skip_larger_than or 0))
        batch = max(1, int(self.opt.fetch_batch_size))
        target_bytes = max(1, int(FETCH_CHUNK_TARGET_BYTES))
        window = max(batch, int(SIZE_PROBE_BATCH_SIZE))
        for wstart in range(0, len(uids), window):
            window_uids = uids[wstart:wstart + window]
            sizes = self.fetch_sizes(window_uids)
            wanted: List[int] = []
            for uid in window_uids:
                size = sizes.get(uid)
                if limit and size is not None and size > limit:
                    # Ни трафика, ни памяти на заведомо слишком большое письмо.
                    log.info("Письмо UID %s (%d Б) не скачивается: больше лимита %d Б.", uid, size, limit)
                    if on_skipped:
                        on_skipped(uid, size)
                    continue
                wanted.append(uid)
            for chunk in _plan_size_chunks(wanted, sizes, batch, target_bytes):
                yield from self._fetch_chunk(chunk)

    def _fetch_chunk(self, chunk: List[int]) -> Iterator[dict]:
        """Скачать одну готовую порцию UID и отдать письма по одному."""
        if not chunk:
            return
        try:
            data = self.client.fetch(chunk, [b"BODY.PEEK[]", b"FLAGS", b"INTERNALDATE", b"RFC822.SIZE"])
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc
        missing: List[int] = []
        for uid in chunk:
            # pop, а не get: отданное письмо сразу перестаёт удерживаться
            # словарём ответа и освобождает память, не дожидаясь конца порции.
            item = data.pop(uid, None)
            if not item:
                missing.append(uid)
                continue
            raw = item.get(b"BODY[]") or item.get(b"RFC822") or b""
            if not raw:
                missing.append(uid)
                continue
            internaldate = item.get(b"INTERNALDATE")
            epoch = internaldate.timestamp() if internaldate else None
            flags = [f.decode() if isinstance(f, bytes) else str(f) for f in (item.get(b"FLAGS") or ())]
            yield {
                "uid": uid,
                "raw": raw,
                "flags": flags,
                "internaldate": epoch,
                "size": int(item.get(b"RFC822.SIZE", len(raw)) or len(raw)),
            }
        if missing:
            # Молча терять письма нельзя: сервер мог их удалить между SEARCH и
            # FETCH, но так же выглядит и сбой выдачи — пишем в лог.
            shown = ", ".join(str(u) for u in missing[:20])
            tail = f" и ещё {len(missing) - 20}" if len(missing) > 20 else ""
            log.warning("FETCH не вернул %d из %d писем (пропущены): UID %s%s",
                        len(missing), len(chunk), shown, tail)

    # -- запись (для восстановления) ----------------------------------------
    def ensure_folder(self, folder: str) -> None:
        """
        Создать папку, если её ещё нет.

        Ответ «папка уже существует» — не ошибка (см. :func:`_is_already_exists_error`),
        всё остальное ошибка настоящая. После CREATE наличие папки
        перепроверяется: сервер мог ответить отказом с непривычной
        формулировкой (хотя папка есть), а мог ответить OK и папку не создать
        (нет прав, недопустимое имя) — тогда все последующие APPEND падали бы
        без внятной причины.
        """
        try:
            if self.client.folder_exists(folder):
                return
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc

        create_error: Optional[BaseException] = None
        try:
            self.client.create_folder(folder)
        except Exception as exc:  # noqa: BLE001
            if not _is_already_exists_error(exc):
                create_error = exc  # вердикт вынесем после перепроверки

        exists: Optional[bool] = None
        try:
            exists = bool(self.client.folder_exists(folder))
        except Exception:  # noqa: BLE001
            exists = None  # перепроверить не удалось — не мешаем работе

        if exists:
            return
        if create_error is not None:
            raise _map_exception(create_error) from create_error
        if exists is False:
            raise ImapProtocolError(
                f"Папка «{folder}» не создана: сервер принял команду CREATE, но папки на сервере нет.",
                hint="Проверьте права на создание папок, допустимость имени и разделитель иерархии.",
            )

    def append(self, folder: str, raw: bytes, flags=(), msg_time=None) -> None:
        try:
            self.client.append(folder, raw, flags=list(flags or ()), msg_time=msg_time)
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc

    def fetch_existing_message_ids(self, folder: str) -> Set[str]:
        """
        Множество Message-ID писем, уже лежащих в папке — ОДНИМ запросом
        `FETCH 1:* BODY.PEEK[HEADER.FIELDS (MESSAGE-ID)]`.

        Нужно проверке дублей при восстановлении: иначе на каждое письмо
        приходится SELECT + SEARCH (на 100 000 писем — сотни тысяч обращений
        к серверу). Ошибку НЕ глушим: «не удалось проверить» и «дублей нет» —
        разные вещи, и решать, что с этим делать, должен вызывающий код.
        """
        info = self.select(folder, readonly=True)
        if not info.get("exists"):
            return set()  # пустая папка: `FETCH 1:*` часть серверов считает ошибкой
        try:
            data = self.client.fetch(["1:*"], [b"BODY.PEEK[HEADER.FIELDS (MESSAGE-ID)]"])
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc
        found: Set[str] = set()
        for item in (data or {}).values():
            for key, value in (item or {}).items():
                if not isinstance(key, bytes) or b"HEADER.FIELDS" not in key:
                    continue
                mid = _header_message_id(value)
                if mid:
                    found.add(mid)
        return found

    def search_header_messageid(self, message_id: str) -> List[int]:
        """
        Поиск письма по Message-ID (поштучный, медленный — запасной путь).

        Ошибку поиска НЕ подменяем пустым списком: пустой ответ означает
        «дублей нет», и на сбое SEARCH письмо заливалось бы повторно.
        """
        if not message_id:
            return []
        try:
            return list(self.client.search(["HEADER", "Message-ID", message_id]))
        except Exception as exc:  # noqa: BLE001
            raise _map_exception(exc) from exc


def probe_account(account: Account, options: Optional[ConnectOptions] = None) -> dict:
    """
    Проверить подключение к ящику. Возвращает структуру для интерфейса:
    {ok, error, hint, capabilities, folders:[{name, selectable, messages?}]}.
    Никогда не бросает исключение — всё упаковывается в результат.
    """
    result = {"ok": False, "error": None, "hint": None, "capabilities": [], "folders": []}
    try:
        with ImapConnection(account, options) as conn:
            result["capabilities"] = conn.capabilities()
            for fi in conn.list_folders():
                result["folders"].append({
                    "name": fi.name,
                    "delimiter": fi.delimiter,
                    "selectable": fi.selectable,
                    "special": [f for f in fi.flags if f not in ("\\HasNoChildren", "\\HasChildren")],
                })
            result["ok"] = True
    except Exception as exc:  # noqa: BLE001
        from ..errors import MailArchiverError
        if isinstance(exc, MailArchiverError):
            result["error"] = exc.message
            result["hint"] = exc.hint
        else:
            result["error"] = str(exc)
    return result
