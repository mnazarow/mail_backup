# Документация MailArchiver

> 📖 **Самый удобный способ читать документацию** — открыть её из веб-интерфейса
> (кнопка «Документация» вверху справа) или по адресу `http://ВАШ_СЕРВЕР:8493/static/docs/index.html`.
> Там всё в одном месте: со скриншотами, схемами и полным справочником параметров.

Материалы в этом каталоге:

| Файл | Содержание |
|------|-----------|
| [01-introduction.md](01-introduction.md) | Что это и зачем, ключевые возможности |
| [02-methodology.md](02-methodology.md) | Как устроена работа: архитектура, алгоритм бэкапа |
| [03-installation.md](03-installation.md) | Установка (systemd и Docker), обновление, удаление |
| [04-configuration.md](04-configuration.md) | Конфигурация, подключение ящиков, OAuth2, reverse proxy |
| [05-parameters-reference.md](05-parameters-reference.md) | **Справочник всех параметров** (генерируется из кода) |
| [06-analytics.md](06-analytics.md) | Разделы «Аналитика» и «Аналитика писем» |
| [11-troubleshooting.md](11-troubleshooting.md) | Устранение неполадок |
| [12-faq.md](12-faq.md) | Частые вопросы |
| [screenshots/](screenshots/) | Скриншоты интерфейса |

Справочник параметров (`05-parameters-reference.md`) генерируется командой:

```bash
python scripts/gen_docs.py
```
Он всегда соответствует установленной версии, так как собирается из описаний в коде.
