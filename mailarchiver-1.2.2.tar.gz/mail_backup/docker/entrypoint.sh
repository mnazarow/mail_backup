#!/usr/bin/env bash
# Точка входа контейнера MailArchiver.
set -Eeuo pipefail

: "${MA_HOST:=0.0.0.0}"
: "${MA_PORT:=8493}"
: "${MAILARCHIVER_DATA:=/data}"

# Первый аргумент — команда mailarchiver (serve по умолчанию)
CMD="${1:-serve}"; shift || true

if [ "$CMD" = "serve" ]; then
  echo "[entrypoint] Запуск MailArchiver на ${MA_HOST}:${MA_PORT}, данные: ${MAILARCHIVER_DATA}"
  # Автосоздание администратора (только если явно задан пароль).
  # Пароль НЕ передаётся аргументом: аргументы видны в `ps` любому процессу
  # контейнера. Предпочтительно MA_ADMIN_PASSWORD_FILE (docker secret).
  if [ -n "${MA_ADMIN_USER:-}" ]; then
    if [ -n "${MA_ADMIN_PASSWORD_FILE:-}" ] && [ -r "${MA_ADMIN_PASSWORD_FILE}" ]; then
      mailarchiver create-admin -u "$MA_ADMIN_USER" --password-file "$MA_ADMIN_PASSWORD_FILE" 2>/dev/null \
        && echo "[entrypoint] Администратор '$MA_ADMIN_USER' создан." \
        || echo "[entrypoint] Администратор уже существует или не создан — пропускаю."
    elif [ -n "${MA_ADMIN_PASSWORD:-}" ]; then
      printf '%s\n' "$MA_ADMIN_PASSWORD" \
        | mailarchiver create-admin -u "$MA_ADMIN_USER" --password-stdin 2>/dev/null \
        && echo "[entrypoint] Администратор '$MA_ADMIN_USER' создан." \
        || echo "[entrypoint] Администратор уже существует или не создан — пропускаю."
    else
      echo "[entrypoint] MA_ADMIN_PASSWORD(_FILE) не задан — администратор не создаётся."
      echo "[entrypoint] Заведите его при первом входе в интерфейс или командой create-admin."
    fi
  fi
  exec mailarchiver serve --host "$MA_HOST" --port "$MA_PORT"
else
  exec mailarchiver "$CMD" "$@"
fi
