"""Версия приложения MailArchiver."""

__version__ = "1.2.2"
APP_NAME = "MailArchiver"
APP_TITLE = "MailArchiver — резервное копирование почты по IMAP"
