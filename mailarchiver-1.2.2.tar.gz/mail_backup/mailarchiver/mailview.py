"""
Разбор письма (RFC 822) для просмотра в веб-интерфейсе: заголовки, текстовая и
HTML-часть, список вложений. HTML отображается на стороне клиента в изолированном
iframe (sandbox) — скрипты не выполняются.
"""
from __future__ import annotations

import email
from email import policy
from typing import Dict, List, Optional, Tuple

#: Предел размера письма, которое разбирается целиком, байт.
#: email.message_from_bytes + get_payload(decode=True) расходуют примерно
#: десятикратный размер файла: письмо с вложением на 100 МБ давало пик 1,5 ГБ,
#: и несколько таких открытий подряд роняли службу вместе с идущими бэкапами.
#: Письма крупнее показываются в «облегчённом» виде: заголовки, список вложений
#: и предложение скачать .eml целиком.
MAX_PARSE_BYTES = 25 * 1024 * 1024

#: Предел размера ОДНОГО вложения, отдаваемого в память при скачивании.
MAX_ATTACHMENT_BYTES = 200 * 1024 * 1024


def _hdr(msg, name: str) -> str:
    try:
        v = msg[name]
        return str(v) if v is not None else ""
    except Exception:  # noqa: BLE001
        return ""


def parse_message(raw: bytes, max_bytes: int = MAX_PARSE_BYTES) -> Dict:
    """Разобрать письмо. Возвращает заголовки, тело (text/html) и список вложений.

    Письма крупнее ``max_bytes`` разбираются только по заголовкам: полный разбор
    расходует около десятикратного объёма файла, и открытие одного письма с
    вложением в сотню мегабайт занимало полтора гигабайта памяти.
    """
    if max_bytes and len(raw) > max_bytes:
        return _headers_only(raw, len(raw), max_bytes)
    try:
        msg = email.message_from_bytes(raw, policy=policy.default)
    except Exception:  # noqa: BLE001
        return {"headers": {}, "text": raw.decode("utf-8", "replace"), "html": "",
                "attachments": [], "truncated": False}

    headers = {
        "from": _hdr(msg, "From"),
        "to": _hdr(msg, "To"),
        "cc": _hdr(msg, "Cc"),
        "subject": _hdr(msg, "Subject"),
        "date": _hdr(msg, "Date"),
        "reply_to": _hdr(msg, "Reply-To"),
        "message_id": _hdr(msg, "Message-ID"),
    }
    text, html = "", ""
    attachments: List[Dict] = []
    idx = 0
    for part in _iter_parts(msg):
        ctype = part.get_content_type()
        disp = part.get_content_disposition()  # 'attachment' | 'inline' | None
        filename = part.get_filename()
        if _is_attachment(ctype, disp, filename):
            attachments.append({
                "index": idx,
                "filename": filename or _default_name(idx, ctype),
                "content_type": ctype,
                "size": _estimated_size(part),
            })
            idx += 1
        elif ctype == "text/plain" and not text:
            text = _get_text(part)
        elif ctype == "text/html" and not html:
            html = _get_text(part)
    # если только HTML — оставим text пустым; клиент покажет HTML в песочнице
    return {"headers": headers, "text": text, "html": html, "attachments": attachments,
            "truncated": False}


def _headers_only(raw: bytes, size: int, max_bytes: int) -> Dict:
    """Облегчённый разбор большого письма: только заголовки, без тела."""
    import email.parser
    head = raw[:262144]
    try:
        msg = email.parser.BytesHeaderParser(policy=policy.default).parsebytes(head)
        headers = {
            "from": _hdr(msg, "From"), "to": _hdr(msg, "To"), "cc": _hdr(msg, "Cc"),
            "subject": _hdr(msg, "Subject"), "date": _hdr(msg, "Date"),
            "reply_to": _hdr(msg, "Reply-To"), "message_id": _hdr(msg, "Message-ID"),
        }
    except Exception:  # noqa: BLE001
        headers = {}
    limit_mb = max_bytes // (1024 * 1024)
    return {
        "headers": headers, "text": "", "html": "", "attachments": [],
        "truncated": True, "size": size,
        "notice": (f"Письмо слишком большое для показа в браузере "
                   f"(предел {limit_mb} МБ). Скачайте его целиком в виде .eml — "
                   f"вложения находятся внутри файла."),
    }



def _is_attachment(ctype: str, disp: Optional[str], filename: Optional[str]) -> bool:
    """Считать ли часть письма вложением.

    Раньше условие было ``disp == "attachment" or (filename and не text/*)``, и
    часть БЕЗ Content-Disposition и БЕЗ имени файла (просто
    ``Content-Type: application/pdf``) не попадала никуда — в карточке письма
    значилось «вложений нет», хотя файл в архиве есть.
    """
    if disp == "attachment":
        return True
    ctype = (ctype or "").lower()
    if filename and not ctype.startswith("text/"):
        return True
    if disp is None and ctype and not ctype.startswith("text/") and not ctype.startswith("multipart/"):
        # неименованная часть без Content-Disposition: картинка, pdf, rfc822
        return True
    return False


def _default_name(idx: int, ctype: str) -> str:
    if (ctype or "").lower() == "message/rfc822":
        return f"forwarded_{idx}.eml"
    ext = {"application/pdf": ".pdf", "image/jpeg": ".jpg", "image/png": ".png",
           "image/gif": ".gif", "application/zip": ".zip"}.get((ctype or "").lower(), "")
    return f"attachment_{idx}{ext}"


def _iter_parts(msg):
    """Обойти части письма, НЕ заходя внутрь приложенных писем.

    ``msg.walk()`` спускается внутрь ``message/rfc822`` и подмешивает вложения
    пересланного письма в общий список — нумерация переставала соответствовать
    тому, что видит пользователь, а само пересланное письмо (его чаще всего и
    нужно скачать) в списке не появлялось вовсе.
    """
    stack = [msg]
    while stack:
        part = stack.pop(0)
        ctype = (part.get_content_type() or "").lower()
        if ctype == "message/rfc822":
            yield part
            continue
        if part.is_multipart():
            payload = part.get_payload()
            if isinstance(payload, list):
                stack = list(payload) + stack
            continue
        yield part


def _rfc822_bytes(part) -> bytes:
    """Байты приложенного письма (message/rfc822) для скачивания."""
    try:
        inner = part.get_payload()
        if isinstance(inner, list) and inner:
            return inner[0].as_bytes()
        if hasattr(inner, "as_bytes"):
            return inner.as_bytes()
    except Exception:  # noqa: BLE001
        pass
    try:
        return part.get_payload(decode=True) or b""
    except Exception:  # noqa: BLE001
        return b""


def _estimated_size(part) -> int:
    """
    Оценить размер вложения, НЕ декодируя его в память: письмо с вложением на
    сотни мегабайт иначе уложило бы сервис (decode=True создаёт полную копию).
    Точный размер отдаётся только при реальном скачивании — см. get_attachment().
    """
    if (part.get_content_type() or "").lower() == "message/rfc822":
        # У приложенного письма payload — список объектов Message, и общая
        # ветка ниже давала размер 0: в карточке письма пересланное письмо
        # числилось пустым, хотя скачивалось нормально.
        return len(_rfc822_bytes(part))
    try:
        payload = part.get_payload(decode=False)
    except Exception:  # noqa: BLE001
        return 0
    if not isinstance(payload, (str, bytes, bytearray)):
        return 0
    encoded_len = len(payload)
    enc = str(part.get("Content-Transfer-Encoding", "") or "").strip().lower()
    if enc == "base64":
        # 4 символа base64 = 3 байта данных (переводы строк дают небольшой запас)
        return max(0, encoded_len * 3 // 4)
    # для 7bit/8bit/binary размер совпадает, для quoted-printable это оценка сверху
    return encoded_len


def _get_text(part) -> str:
    """Извлечь текст части, устойчиво к отсутствию/неверной кодировке."""
    try:
        payload = part.get_payload(decode=True)
    except Exception:  # noqa: BLE001
        payload = None
    if payload is None:
        try:
            return part.get_content() or ""
        except Exception:  # noqa: BLE001
            return ""
    charset = part.get_content_charset()
    if charset:
        try:
            # Кодировка ОБЪЯВЛЕНА — декодируем именно ею, битые байты заменяем.
            # Перебор здесь недопустим: koi8-r (и latin-1) успешно «декодируют»
            # любые 256 байт, и одно испорченное UTF-8 письмо превратилось бы в
            # сплошную абракадабру вместо пары символов-заменителей.
            return payload.decode(charset, "replace")
        except LookupError:
            pass  # кодировка неизвестна Python — переходим к перебору
    # charset не указан или неизвестен — пробуем распространённые кодировки
    for enc in ("utf-8", "cp1251", "koi8-r", "latin-1"):
        try:
            return payload.decode(enc, "strict")
        except (LookupError, UnicodeDecodeError):
            continue
    return payload.decode("utf-8", "replace")


def get_attachment(raw: bytes, index: int,
                   max_bytes: int = MAX_ATTACHMENT_BYTES) -> Optional[Tuple[str, str, bytes]]:
    """Вернуть (имя, тип, содержимое) вложения по его порядковому номеру.

    ``max_bytes`` ограничивает размер письма, из которого вообще достаётся
    вложение: разбор занимает около десятикратного объёма файла.
    """
    if max_bytes and len(raw) > max_bytes:
        raise ValueError(f"Письмо слишком большое для извлечения вложения "
                         f"({len(raw) // (1024 * 1024)} МБ). Скачайте письмо целиком (.eml).")
    try:
        msg = email.message_from_bytes(raw, policy=policy.default)
    except Exception:  # noqa: BLE001
        return None
    idx = 0
    for part in _iter_parts(msg):
        ctype = part.get_content_type()
        disp = part.get_content_disposition()
        filename = part.get_filename()
        if _is_attachment(ctype, disp, filename):
            if idx == index:
                if ctype == "message/rfc822":
                    payload = _rfc822_bytes(part)
                else:
                    try:
                        payload = part.get_payload(decode=True) or b""
                    except Exception:  # noqa: BLE001
                        payload = b""
                return (filename or _default_name(idx, ctype), ctype, payload)
            idx += 1
    return None
