"""Версия приложения MailArchiver."""

__version__ = "1.7.0"
APP_NAME = "MailArchiver"
APP_TITLE = "MailArchiver — резервное копирование почты по IMAP"
