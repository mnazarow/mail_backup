"""Версия приложения MailArchiver."""

__version__ = "1.3.0"
APP_NAME = "MailArchiver"
APP_TITLE = "MailArchiver — резервное копирование почты по IMAP"
