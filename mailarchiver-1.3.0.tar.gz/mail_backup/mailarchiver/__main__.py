"""
Точка входа и командная строка MailArchiver.

Использование::

    mailarchiver serve                 # запустить веб-сервис
    mailarchiver create-admin          # создать администратора
    mailarchiver reset-2fa -u NAME     # отключить 2FA пользователя (потерян телефон)
    mailarchiver storage-key           # состояние шифрования копии (--generate ПУТЬ — новый ключ)
    mailarchiver reset-password -u имя # сбросить пароль пользователя
    mailarchiver check-config          # проверить конфигурацию
    mailarchiver version
"""
from __future__ import annotations

import argparse
import getpass
import os
import sys

from .config import load_config
from .errors import MailArchiverError
from .version import __version__, APP_TITLE


def _build_db(cfg):
    from .security import SecretBox
    from .database import Database
    box = SecretBox(cfg.secret_key())
    db = Database(cfg.db_path, box, busy_timeout_ms=int(cfg.get("database", "busy_timeout_ms", 10000)),
                  wal=bool(cfg.get("database", "wal", True)))
    db.init_schema()
    return db


def cmd_serve(args) -> int:
    import uvicorn
    cfg = load_config(args.config)
    if args.config:
        os.environ["MAILARCHIVER_CONFIG"] = args.config
    host = args.host or cfg.server.get("host", "127.0.0.1")
    port = args.port or int(cfg.server.get("port", 8493))
    print(f"{APP_TITLE} {__version__}")
    print(f"Запуск веб-сервиса на http://{host}:{port}  (данные: {cfg.data_dir})")
    # workers=1 обязательно: планировщик и очередь должны быть в одном процессе
    # proxy_headers=False намеренно: разбор X-Forwarded-For делает собственный
    # ProxyHeadersMiddleware (mailarchiver/web/proxy.py). uvicorn брал ЛЕВОЕ
    # значение цепочки — целиком подконтрольное клиенту, из-за чего защита от
    # подбора пароля обходилась подстановкой заголовка.
    uvicorn.run("mailarchiver.web.app:app", host=host, port=port, workers=1,
                log_level=str(cfg.logging_cfg.get("level", "info")).lower(),
                proxy_headers=False, forwarded_allow_ips=None)
    return 0


def _password_from_args(args, prompt: str) -> str:
    """Пароль из --password-file/--password-stdin/-p или интерактивно.

    Аргумент командной строки виден в ``ps`` всем пользователям машины, поэтому
    в скриптах и контейнерах пароль следует передавать файлом или через stdin.
    """
    path = getattr(args, "password_file", None)
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read().strip("\r\n")
    if getattr(args, "password_stdin", False):
        return sys.stdin.readline().strip("\r\n")
    if getattr(args, "password", None):
        return args.password
    return getpass.getpass(prompt)


def cmd_create_admin(args) -> int:
    from .security import hash_password, check_password_policy
    cfg = load_config(args.config)
    db = _build_db(cfg)
    username = args.username or input("Имя администратора [admin]: ").strip() or "admin"
    if db.get_user_by_name(username):
        print(f"Пользователь «{username}» уже существует.", file=sys.stderr)
        return 1
    password = _password_from_args(args, "Пароль: ")
    err = check_password_policy(password, int(cfg.security.get("min_password_length", 8)))
    if err:
        print(err, file=sys.stderr)
        return 1
    uid = db.create_user(username, hash_password(password), role="admin")
    print(f"Администратор «{username}» создан (id={uid}).")
    return 0


def cmd_reset_password(args) -> int:
    from .security import hash_password, check_password_policy
    cfg = load_config(args.config)
    db = _build_db(cfg)
    user = db.get_user_by_name(args.username)
    if not user:
        print(f"Пользователь «{args.username}» не найден.", file=sys.stderr)
        return 1
    password = _password_from_args(args, "Новый пароль: ")
    err = check_password_policy(password, int(cfg.security.get("min_password_length", 8)))
    if err:
        print(err, file=sys.stderr)
        return 1
    db.set_user_password(user["id"], hash_password(password))
    print(f"Пароль пользователя «{args.username}» изменён.")
    return 0


def cmd_reset_2fa(args) -> int:
    """Отключить двухфакторный вход пользователя (потерян телефон)."""
    cfg = load_config(args.config)
    db = _build_db(cfg)
    user = db.get_user_by_name(args.username)
    if not user:
        print(f"Пользователь «{args.username}» не найден.", file=sys.stderr)
        return 1
    if not user["totp_enabled"]:
        # Ничего не меняем и сеансы не трогаем: 2FA и так выключена
        # (частая ошибка — опечатка в имени соседней учётной записи).
        db.disable_totp(user["id"])  # сбросить недонастроенный секрет, если был
        print(f"У пользователя «{user['username']}» двухфакторный вход не был включён — "
              f"для входа хватает пароля.")
        return 0
    db.disable_totp(user["id"])
    db.delete_user_sessions(user["id"])
    db.add_audit("cli", "2fa_reset", user["username"])
    print(f"Двухфакторный вход пользователя «{user['username']}» отключён, его сеансы завершены.")
    print("При следующем входе хватит пароля; включите 2FA заново в профиле.")
    return 0


def cmd_storage_key(args) -> int:
    """Ключ шифрования локальной копии: создать или показать состояние.

    Просмотр состояния ТОЛЬКО читает: ни ключ, ни каталоги, ни файлы базы не
    создаются (раньше команда, запущенная через sudo, создавала ключ
    root:root 0600, который служба потом не могла прочитать).
    """
    from .storage import crypto
    cfg = load_config(args.config)
    if args.generate:
        path = os.path.abspath(args.generate)
        parent = os.path.dirname(path)
        parent_existed = os.path.isdir(parent)
        try:
            key = crypto.generate_key_file(path)
        except Exception as exc:  # noqa: BLE001
            print(f"Не удалось создать ключ: {exc}", file=sys.stderr)
            return 1
        print(f"Ключ создан: {path} (отпечаток {crypto.key_id_of(key).hex()}).")
        print("Дальше:")
        if not parent_existed:
            print(f"  1) chown root:mailarchiver {parent} {path} && chmod 750 {parent} && chmod 640 {path}")
        else:
            print(f"  1) chown root:mailarchiver {path} && chmod 640 {path}")
        print(f"  2) в config.yaml: storage.encryption_key_file: \"{path}\" и storage.encrypt: true")
        print("  3) СКОПИРУЙТЕ ключ в надёжное место отдельно от каталога данных.")
        return 0
    import json
    import sqlite3
    settings, meta, counts = {}, {}, {"total": 0, "encrypted": 0}
    if os.path.exists(cfg.db_path):
        try:
            conn = sqlite3.connect(f"file:{cfg.db_path}?mode=ro", uri=True, timeout=5)
            try:
                for key, value in conn.execute(
                        "SELECT key, value FROM settings WHERE key LIKE 'storage.%'"):
                    try:
                        settings[key] = json.loads(value)
                    except (TypeError, ValueError):
                        settings[key] = value
                for key, value in conn.execute("SELECT key, value FROM meta"):
                    meta[key] = value
                row = conn.execute("SELECT COUNT(*), COALESCE(SUM(CASE WHEN stored_path LIKE '%.enc' "
                                   "THEN 1 ELSE 0 END), 0) FROM messages").fetchone()
                counts = {"total": int(row[0] or 0), "encrypted": int(row[1] or 0)}
            finally:
                conn.close()
        except sqlite3.Error as exc:
            print(f"База данных не читается ({exc}) — показываю только файл ключа.", file=sys.stderr)

    def opt(key: str):
        return settings.get(f"storage.{key}", cfg.get("storage", key))

    raw_path = str(opt("encryption_key_file") or "").strip()
    path = os.path.abspath(raw_path) if raw_path else os.path.join(cfg.data_dir, "storage.key")
    inside = path.startswith(os.path.abspath(cfg.data_dir) + os.sep)
    key_id, error = None, None
    if os.path.exists(path):
        try:
            key_id = crypto.key_id_of(crypto.load_key_file(path)).hex()
        except Exception as exc:  # noqa: BLE001
            error = f"Файл ключа не читается: {getattr(exc, 'message', exc)}"
    elif bool(opt("encrypt")) or meta.get("storage_key_id"):
        error = f"Файл ключа не найден: {path}"
    recorded = meta.get("storage_key_id")
    if key_id and recorded and key_id != recorded:
        error = f"Ключ {path} не тот, которым шифровался архив (ожидался отпечаток {recorded})."
    print(f"Файл ключа:          {path}" + ("  (внутри каталога данных!)" if inside else ""))
    print(f"Отпечаток ключа:     {key_id or '—'}")
    print(f"Ожидаемый отпечаток: {recorded or '— (архив ещё не шифровался)'}")
    print(f"Шифрование новых:    {'включено' if opt('encrypt') else 'выключено'} (в настройках)")
    print(f"Писем зашифровано:   {counts['encrypted']} из {counts['total']}")
    for warning in crypto.key_file_warnings(path):
        print(f"ВНИМАНИЕ: {warning}", file=sys.stderr)
    if error:
        print(f"ОШИБКА: {error}", file=sys.stderr)
        return 1
    return 0


def cmd_check_config(args) -> int:
    try:
        # create_dirs=False: проверка ничего не создаёт и не меняет права каталогов
        cfg = load_config(args.config, create_dirs=False)
    except Exception as exc:  # noqa: BLE001
        print(f"ОШИБКА конфигурации: {getattr(exc, 'message', exc)}", file=sys.stderr)
        hint = getattr(exc, "hint", None)
        if hint:
            print(f"Подсказка: {hint}", file=sys.stderr)
        return 1
    print(f"{APP_TITLE} {__version__}")
    print(f"Файл конфигурации : {cfg.source_path or '(значения по умолчанию)'}")
    print(f"Каталог данных    : {cfg.data_dir}")
    print(f"База данных        : {cfg.db_path}")
    print(f"Каталог копий      : {cfg.mail_root}")
    print(f"Веб-интерфейс      : http://{cfg.server['host']}:{cfg.server['port']}")
    for warning in cfg.warnings:
        print(f"Предупреждение: {warning}")
    print("Конфигурация корректна ✓" + (" (есть предупреждения)" if cfg.warnings else ""))
    return 0


def cmd_version(args) -> int:
    print(f"{APP_TITLE} {__version__}")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="mailarchiver", description=APP_TITLE)
    parser.add_argument("--config", "-c", help="путь к config.yaml")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("serve", help="запустить веб-сервис")
    p.add_argument("--host"); p.add_argument("--port", type=int)
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("create-admin", help="создать администратора")
    p.add_argument("-u", "--username"); p.add_argument("-p", "--password")
    p.add_argument("--password-file", help="файл с паролем (безопаснее, чем -p: аргументы видны в ps)")
    p.add_argument("--password-stdin", action="store_true", help="прочитать пароль из стандартного ввода")
    p.set_defaults(func=cmd_create_admin)

    p = sub.add_parser("reset-password", help="сбросить пароль пользователя")
    p.add_argument("-u", "--username", required=True); p.add_argument("-p", "--password")
    p.add_argument("--password-file", help="файл с паролем")
    p.add_argument("--password-stdin", action="store_true", help="прочитать пароль из стандартного ввода")
    p.set_defaults(func=cmd_reset_password)

    p = sub.add_parser("reset-2fa", help="отключить двухфакторный вход пользователя (потерян телефон)")
    p.add_argument("-u", "--username", required=True)
    p.set_defaults(func=cmd_reset_2fa)

    p = sub.add_parser("storage-key", help="ключ шифрования локальной копии: состояние или создание")
    p.add_argument("--generate", metavar="ПУТЬ", help="создать новый ключ в указанном файле (не перезаписывает)")
    p.set_defaults(func=cmd_storage_key)

    p = sub.add_parser("check-config", help="проверить конфигурацию")
    p.set_defaults(func=cmd_check_config)

    p = sub.add_parser("version", help="показать версию")
    p.set_defaults(func=cmd_version)

    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        args.func = cmd_serve
        args.host = None
        args.port = None
    try:
        return args.func(args)
    except MailArchiverError as exc:
        # понятное сообщение вместо трассировки (неверный путь, конфиг и т. п.)
        print(f"ОШИБКА: {exc.message}", file=sys.stderr)
        if exc.hint:
            print(f"Подсказка: {exc.hint}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"ОШИБКА: {exc.strerror or exc}: {exc.filename or ''}".rstrip(": "), file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print("\nПрервано.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
